/****************************************************************
 *
 * File: ProjectHelloWorld
 * By: Arjun Parujanwala
 * Date: 02-02-2024
 *
 * Description: Hello World.
 *
 ****************************************************************/
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello World.");
    }
}